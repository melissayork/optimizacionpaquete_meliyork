from .biseccion import biseccion
from .busquedaDorada import busquedaDorada
from .fibonacci import fibonacci_search
from .intervalHalving import interval_halving_method
from .newtonRaphson import newton_raphson
from .secante import secante